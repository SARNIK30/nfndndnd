#!/usr/bin/env python3
"""
Скрипт для запуска Телеграм Бота Покемонов через Replit Workflow.
Оптимизирован для долгосрочной работы на платформе Replit.
"""

import asyncio
import logging
import os
import signal
import sys
import time
from bot import run_polling

# Настройка логирования
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def main():
    """Основная функция для запуска бота с обработкой перезапуска."""
    try:
        logger.info("Запуск бота в режиме Workflow...")
        await run_polling()
    except Exception as e:
        logger.error(f"Ошибка при запуске бота: {e}")
        # Перезапуск через 30 секунд при ошибке
        logger.info("Перезапуск через 30 секунд...")
        time.sleep(30)
        return 1  # Код ошибки для перезапуска
    return 0

if __name__ == "__main__":
    try:
        exitcode = asyncio.run(main())
        sys.exit(exitcode)
    except KeyboardInterrupt:
        logger.info("Бот остановлен пользователем.")
        sys.exit(0)
