#!/usr/bin/env python3
"""
Скрипт для запуска Телеграм Бота Покемонов через Replit Workflow.
Оптимизирован для долгосрочной работы на платформе Replit.
"""

import asyncio
import logging
import signal
import sys
import time
import os
import traceback
from bot import run_polling, register_handlers

# Проверка доступности переменных окружения
if not os.environ.get("BOT_TOKEN"):
    print("ОШИБКА: Переменная окружения BOT_TOKEN не найдена!")
    sys.exit(1)

# Отключаем базовые логи библиотек, чтобы избежать утечки данных
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("telegram").setLevel(logging.INFO)
logging.getLogger("asyncio").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("pokemon_bot.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Флаг для остановки бота
should_stop = False

# Создаем файл-маркер для отслеживания перезапусков
def create_heartbeat_file():
    try:
        with open("bot_heartbeat.txt", "w") as f:
            f.write(str(time.time()))
    except Exception as e:
        logger.error(f"Ошибка при создании файла heartbeat: {e}")

def signal_handler(sig, frame):
    """Обработчик сигналов для корректного завершения бота."""
    global should_stop
    logger.info("Получен сигнал завершения. Остановка бота...")
    should_stop = True

async def main():
    """Основная функция для запуска бота с обработкой перезапуска."""
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    global should_stop
    retry_count = 0
    max_retries = 10  # Увеличили максимальное количество попыток
    backoff_factor = 1.5
    
    # Бесконечный цикл для работы бота 24/7
    while not should_stop:
        try:
            logger.info("Запуск бота Pokemon...")
            # Создаем файл-маркер перед запуском
            create_heartbeat_file()
            
            # Запускаем бота
            await run_polling()
            
            # Если run_polling() завершилось без ошибки, но мы не хотели остановить бота,
            # значит произошло неожиданное завершение и нужен перезапуск
            if not should_stop:
                logger.warning("Бот неожиданно завершился без ошибки. Перезапуск...")
                await asyncio.sleep(5)  # Небольшая пауза перед перезапуском
        except Exception as e:
            retry_count += 1
            wait_time = min(60, backoff_factor ** retry_count)
            
            # Логируем ошибку с полным стеком
            logger.error(f"Произошла ошибка при работе бота: {e}")
            logger.error(f"Подробная информация об ошибке: {traceback.format_exc()}")
            logger.info(f"Попытка перезапуска {retry_count}/{max_retries} через {wait_time} секунд...")
            
            # Обновляем файл-маркер для показа, что бот всё ещё пытается работать
            create_heartbeat_file()
            
            if retry_count >= max_retries:
                logger.error("Достигнуто максимальное количество попыток перезапуска. Временная остановка...")
                # Сброс счетчика попыток после долгой паузы
                await asyncio.sleep(300)  # Пауза 5 минут
                retry_count = 0
            else:
                await asyncio.sleep(wait_time)
        else:
            # Если бот завершился без ошибок, сбрасываем счетчик
            retry_count = 0
        
        # Обновляем файл-маркер после каждой итерации цикла
        create_heartbeat_file()
            
    logger.info("Бот остановлен.")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Бот остановлен вручную.")
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        sys.exit(1)