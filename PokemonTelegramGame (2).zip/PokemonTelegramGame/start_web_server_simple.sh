#!/bin/bash
# Простой скрипт для запуска веб-сервера в фоновом режиме

echo "Запуск веб-сервера для мониторинга бота в фоновом режиме..."

# Остановка предыдущего экземпляра, если он запущен
if [ -f web_server_pid.txt ]; then
    old_pid=$(cat web_server_pid.txt)
    if ps -p $old_pid > /dev/null; then
        echo "Остановка предыдущего экземпляра веб-сервера (PID: $old_pid)..."
        kill $old_pid
        sleep 2
    fi
fi

# Запуск в foreground режиме для проверки ошибок
echo "Тестовый запуск веб-сервера..."
python3 ping_endpoint.py &
pid=$!
echo $pid > web_server_pid.txt
sleep 2

# Проверка, работает ли процесс
if ps -p $pid > /dev/null; then
    echo "Веб-сервер успешно запущен с PID: $pid"
    echo "Логи доступны в файле: web_server.log"
    echo "Мониторинг доступен по адресу: https://$REPL_SLUG.$REPL_OWNER.repl.co/health"
    echo "Для мониторинга с UptimeRobot используйте: https://$REPL_SLUG.$REPL_OWNER.repl.co/ping"
else
    echo "ОШИБКА: Веб-сервер не запустился!"
    echo "Попробуйте запустить его вручную: python3 ping_endpoint.py"
fi