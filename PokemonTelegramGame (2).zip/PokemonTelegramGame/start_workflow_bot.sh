#!/bin/bash
# Скрипт для запуска бота в режиме Workflow на Replit

echo "===== Запуск Pokémon бота в режиме Workflow ====="
echo "Дата и время: $(date)"

# Проверка наличия необходимых переменных окружения
if [ -z "$BOT_TOKEN" ]; then
    echo "❌ Ошибка: Переменная окружения BOT_TOKEN не установлена"
    echo "Установите BOT_TOKEN в консоли Replit (Tools -> Secrets)"
    exit 1
fi

if [ -z "$ADMIN_IDS" ]; then
    echo "⚠️ Предупреждение: Переменная окружения ADMIN_IDS не установлена"
    echo "Рекомендуется установить ADMIN_IDS для доступа к админ-панели"
fi

# Проверка, существует ли файл heartbeat
if [ -f "bot_running.txt" ]; then
    echo "⚠️ Файл heartbeat уже существует. Возможно, бот уже запущен."
    echo "Содержимое файла heartbeat:"
    cat bot_running.txt
    echo ""
    echo "Если вы уверены, что бот не запущен, удалите файл bot_running.txt:"
    echo "rm bot_running.txt"
    echo ""
    echo "Продолжаем запуск..."
    rm -f bot_running.txt
fi

# Останавливаем возможные существующие процессы
echo "Останавливаем возможные существующие процессы бота..."
pkill -f "python3 pokemon_bot_workflow.py" || true
pkill -f "python3 run_bot_forever.py" || true
sleep 2

# Создаем heartbeat файл
echo "Bot starting up at $(date)" > bot_running.txt

# Запуск бота напрямую (для отладки и тестирования)
echo "Запуск бота напрямую в фоновом режиме..."
nohup python3 pokemon_bot_workflow.py > pokemon_bot_workflow.log 2>&1 &
echo $! > bot_pid.txt
echo "Бот запущен с PID: $(cat bot_pid.txt)"

# Ожидание 5 секунд для запуска
echo "Ожидание 5 секунд для инициализации бота..."
sleep 5

# Проверка статуса бота
echo "Проверка статуса бота:"
python3 check_bot_status.py

echo ""
echo "===== Запуск завершен ====="
echo "Для проверки статуса бота в любое время, выполните:"
echo "python3 check_bot_status.py"
echo ""
echo "Для просмотра логов бота, выполните:"
echo "tail -f pokemon_bot_workflow.log"