#!/bin/bash

# Проверяем, запущен ли бот
if [ ! -f "bot_launcher.pid" ]; then
    echo "Бот не запущен"
    exit 0
fi

# Получаем PID бота
PID=$(cat bot_launcher.pid)

# Проверяем, существует ли процесс с таким PID
if ps -p $PID > /dev/null; then
    echo "Останавливаем бота с PID $PID..."
    kill $PID
    echo "Бот остановлен"
else
    echo "Процесс бота с PID $PID не найден"
fi

# Удаляем файл с PID
rm bot_launcher.pid
