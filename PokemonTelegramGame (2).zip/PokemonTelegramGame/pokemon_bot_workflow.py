#!/usr/bin/env python3
"""
Улучшенный скрипт для запуска Telegram бота в режиме Workflow на Replit.
Обеспечивает непрерывную работу и автоматическое восстановление при сбоях.
"""

import asyncio
import datetime
import logging
import os
import signal
import sys
import time
import traceback

from telegram.ext import ApplicationBuilder

from bot import error_handler, register_handlers
from config import BOT_TOKEN

# Настройка логирования
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
    handlers=[
        logging.FileHandler("pokemon_bot_workflow.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Файл для проверки активности бота
HEARTBEAT_FILE = "bot_running.txt"


def create_heartbeat_file():
    """Создание файла-индикатора активности бота."""
    try:
        with open(HEARTBEAT_FILE, "w") as f:
            f.write(f"Bot running since: {datetime.datetime.now()}")
    except Exception as e:
        logger.error(f"Ошибка при создании heartbeat файла: {e}")


def update_heartbeat_file():
    """Обновление файла-индикатора активности бота."""
    try:
        with open(HEARTBEAT_FILE, "w") as f:
            f.write(f"Bot running. Last update: {datetime.datetime.now()}")
    except Exception as e:
        logger.error(f"Ошибка при обновлении heartbeat файла: {e}")


async def run_polling_bot():
    """Запуск бота в режиме поллинга с улучшенной обработкой ошибок."""
    logger.info("Запуск бота в режиме поллинга...")
    
    try:
        # Создаем приложение бота
        application = ApplicationBuilder().token(BOT_TOKEN).build()
        
        # Регистрируем обработчики команд и сообщений
        register_handlers()
        
        # Устанавливаем обработчик ошибок
        application.add_error_handler(error_handler)
        
        # Создаем heartbeat файл перед запуском
        create_heartbeat_file()
        
        # Инициализация и запуск приложения
        await application.initialize()
        await application.start()
        
        # Запуск поллинга с расширенным списком разрешенных обновлений
        await application.updater.start_polling(
            allowed_updates=["message", "callback_query", "inline_query", "chat_member", "chat_join_request"]
        )
        
        logger.info("Поллинг бота успешно запущен. Бот работает.")
        
        # Бесконечный цикл для поддержания бота активным с обновлением heartbeat
        counter = 0
        while True:
            await asyncio.sleep(10)  # Проверка каждые 10 секунд
            counter += 1
            if counter >= 60:  # Обновляем heartbeat каждые 10 минут
                update_heartbeat_file()
                counter = 0
                logger.info("Heartbeat обновлен. Бот работает нормально.")
                
    except Exception as e:
        logger.error(f"Ошибка при запуске поллинга: {e}")
        logger.error(traceback.format_exc())
        raise  # Пробрасываем исключение для обработки в main_loop
    finally:
        # Корректное завершение бота
        try:
            logger.info("Остановка бота...")
            if os.path.exists(HEARTBEAT_FILE):
                os.remove(HEARTBEAT_FILE)
            await application.stop()
            await application.shutdown()
        except Exception as e:
            logger.error(f"Ошибка при остановке бота: {e}")


async def main():
    """Основная функция для запуска бота с обработкой перезапуска."""
    restart_count = 0
    last_restart_time = time.time()
    max_restarts = 5
    restart_window = 60  # секунды
    
    while True:
        try:
            # Проверяем, не превышен ли лимит перезапусков
            current_time = time.time()
            if current_time - last_restart_time > restart_window:
                # Сбрасываем счетчик, если прошло больше времени, чем restart_window
                restart_count = 0
                last_restart_time = current_time
            
            if restart_count >= max_restarts:
                # Если превышен лимит перезапусков, ждем некоторое время
                wait_time = 60  # Ждем 1 минуту перед следующей попыткой
                logger.warning(f"Превышен лимит перезапусков. Ожидание {wait_time} секунд...")
                await asyncio.sleep(wait_time)
                # Сбрасываем счетчик перезапусков
                restart_count = 0
                last_restart_time = time.time()
            
            # Запускаем бота
            start_time = datetime.datetime.now()
            logger.info(f"Запуск бота Pokémon (попытка #{restart_count + 1}): {start_time}")
            
            await run_polling_bot()
            
        except KeyboardInterrupt:
            logger.info("Получен сигнал прерывания. Завершение работы...")
            break
        except Exception as e:
            # Увеличиваем счетчик перезапусков
            restart_count += 1
            
            # Логируем ошибку
            logger.error(f"Ошибка в работе бота: {e}")
            logger.error(traceback.format_exc())
            
            # Ждем немного перед перезапуском
            wait_time = min(5 * restart_count, 30)  # Максимум 30 секунд
            logger.info(f"Перезапуск через {wait_time} секунд...")
            await asyncio.sleep(wait_time)


def signal_handler(sig, frame):
    """Обработчик сигналов для корректного завершения бота."""
    logger.info(f"Получен сигнал {sig}. Завершение работы...")
    if os.path.exists(HEARTBEAT_FILE):
        os.remove(HEARTBEAT_FILE)
    sys.exit(0)


if __name__ == "__main__":
    # Установка обработчиков сигналов
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    logger.info("===== Запуск бота Pokémon в режиме Workflow =====")
    logger.info(f"Версия Python: {sys.version}")
    logger.info(f"Время запуска: {datetime.datetime.now()}")
    
    # Запуск основного цикла
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Получен сигнал прерывания. Завершение работы...")
    except Exception as e:
        logger.critical(f"Критическая ошибка: {e}")
        logger.critical(traceback.format_exc())
    
    logger.info("===== Бот завершил работу =====")