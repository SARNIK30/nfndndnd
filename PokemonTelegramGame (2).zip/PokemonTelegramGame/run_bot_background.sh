#!/bin/bash

# Очистка предыдущих логов для лучшей диагностики
if [ -f "pokemon_bot.log" ]; then
    echo "--- Новый запуск бота $(date) ---" >> pokemon_bot.log
fi

# Проверка доступности переменных окружения
if [ -z "$BOT_TOKEN" ]; then
    echo "ОШИБКА: Переменная окружения BOT_TOKEN не найдена!"
    exit 1
fi

# Проверка наличия файла run_bot_workflow.py
if [ ! -f "run_bot_workflow.py" ]; then
    echo "ОШИБКА: Файл run_bot_workflow.py не найден!"
    exit 1
fi

# Запуск бота в фоновом режиме с игнорированием завершения сессии
# Создаем файл для контроля работы бота
echo "1" > bot_running.txt

# Запускаем бот с улучшенными параметрами для фоновой работы
cd $(dirname "$0")  # Переходим в директорию скрипта
nohup python run_bot_workflow.py >> pokemon_bot.log 2>&1 & disown
echo $! > bot.pid
chmod 666 bot.pid  # Устанавливаем разрешения для файла PID

# Создаем файл heartbeat для мониторинга
date > bot_heartbeat.txt
chmod 666 bot_heartbeat.txt

echo "Бот запущен в фоновом режиме с PID $(cat bot.pid)"
echo "Для проверки статуса используйте: ps aux | grep $(cat bot.pid)"
echo "Для остановки используйте: kill $(cat bot.pid)"

# Дополнительная проверка запуска процесса
sleep 2
if ps -p $(cat bot.pid) > /dev/null; then
    echo "Процесс успешно запущен и работает."
else
    echo "ВНИМАНИЕ: Процесс не обнаружен после запуска. Проверьте логи."
    exit 1
fi