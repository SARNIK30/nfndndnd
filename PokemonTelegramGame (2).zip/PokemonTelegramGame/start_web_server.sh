#!/bin/bash
# Скрипт для запуска веб-сервера мониторинга бота

echo "Запуск веб-сервера для мониторинга..."

# Остановка предыдущего экземпляра, если он запущен
if [ -f web_server_pid.txt ]; then
    old_pid=$(cat web_server_pid.txt)
    if ps -p $old_pid > /dev/null; then
        echo "Остановка предыдущего экземпляра веб-сервера (PID: $old_pid)..."
        kill $old_pid
        sleep 2
    fi
fi

# Установка переменной FLASK_APP для запуска
export FLASK_APP=ping_endpoint.py

# Запуск Flask-приложения в фоновом режиме
nohup flask run --host=0.0.0.0 --port=5000 > web_server.log 2>&1 &
echo $! > web_server_pid.txt

echo "Веб-сервер мониторинга запущен с PID: $(cat web_server_pid.txt)"
echo "Веб-сервер доступен по URL: https://$REPL_SLUG.$REPL_OWNER.repl.co"
echo "Эндпоинты:"
echo "  /ping - простой эндпоинт для проверки доступности"
echo "  /health - подробная информация о состоянии бота"
echo "  / - общая информация о боте"
echo "Логи доступны в файле: web_server.log"