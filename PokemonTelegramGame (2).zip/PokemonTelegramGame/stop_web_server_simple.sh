#!/bin/bash
# Простой скрипт для остановки веб-сервера

echo "Остановка веб-сервера для мониторинга..."

if [ -f web_server_pid.txt ]; then
    PID=$(cat web_server_pid.txt)
    if ps -p $PID > /dev/null; then
        echo "Остановка процесса с PID: $PID"
        kill $PID
        rm web_server_pid.txt
        echo "Веб-сервер остановлен."
    else
        echo "Процесс с PID $PID не найден."
        rm web_server_pid.txt
    fi
else
    echo "Файл PID не найден. Веб-сервер, возможно, не запущен."
fi