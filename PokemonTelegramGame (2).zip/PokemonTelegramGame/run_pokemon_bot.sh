#!/bin/bash

echo "Запуск телеграм-бота Pokemon в режиме воркфлоу..."
# Создаем файл для контроля работы бота
echo "Bot started at $(date)" > bot_running.txt

# Запускаем бот с использованием улучшенного скрипта для воркфлоу
cd $(dirname "$0")
python3 pokemon_bot_workflow.py