# Руководство по настройке 24/7 работы бота на Replit

Данное руководство поможет настроить непрерывную работу (24/7) Телеграм бота с покемонами на платформе Replit.

## Необходимые условия

1. Аккаунт на Replit (желательно с Replit Hacker/Pro Plan для стабильной работы)
2. Настроенный бот с токеном Telegram API
3. Настроенные переменные окружения (BOT_TOKEN, ADMIN_IDS, WEBHOOK_URL)

## Шаги для настройки 24/7 работы

### 1. Настройка Persistent Workflows

Replit Persistent Workflows позволяют вашему боту работать в фоновом режиме даже после закрытия вкладки Replit.

1. Проверьте, что файл конфигурации `.replit.d/persistent_workflows/pokemon_bot.yml` содержит правильные настройки:
   ```yaml
   name: pokemon_bot
   description: Телеграм бот с покемонами, работающий в режиме поллинга
   run: python3 pokemon_bot_workflow.py
   persistent: true
   onBoot: true
   language: python3
   ```

2. Убедитесь, что файл `.replit.d/persistent_workflows/pokemon_bot.replit` настроен правильно:
   ```
   run = "python3 pokemon_bot_workflow.py"
   language = "python3"
   persistent = true
   onBoot = true
   keep-alive-timeout-ms = 30000
   autostart = true
   ```

3. Проверьте файл `.replit.d/workflows.json`:
   ```json
   {
     "workflows": [
       {
         "name": "pokemon_bot",
         "persistent": true,
         "onBoot": true,
         "command": "python3 pokemon_bot_workflow.py",
         "restartOn": {
           "fileChange": {
             "paths": ["pokemon_bot_workflow.py", "bot.py", "config.py", "storage.py"]
           }
         },
         "ignorePorts": true,
         "quiet": false
       }
     ]
   }
   ```

### 2. Запуск workflow вручную

Запустите workflow из Shell панели Replit:

```bash
chmod +x start_workflow_bot.sh
./start_workflow_bot.sh
```

### 3. Проверка статуса бота

Проверьте, что бот запустился и работает:

```bash
python3 check_bot_status.py
```

### 4. Настройка системы мониторинга

Для обеспечения стабильной работы настройте мониторинг с автоматическим перезапуском:

1. Используйте скрипт `monitor_bot.py` для регулярной проверки:
   ```bash
   python3 monitor_bot.py
   ```

2. Для автоматической проверки используйте сторонний сервис UptimeRobot (https://uptimerobot.com/):
   - Зарегистрируйтесь на UptimeRobot
   - Создайте новый монитор типа HTTP(s)
   - Укажите URL вашего проекта на Replit (например, https://pokemon-bot.yourusername.repl.co)
   - Настройте интервал проверки (например, каждые 5 минут)

3. Для доступа к URL вашего проекта создайте простой веб-сервер для пинга (уже реализован в `main.py`).

### 5. Настройка Replit Always On

Если у вас есть подписка Replit Hacker/Pro:

1. В проекте перейдите в раздел "Tools" -> "Always On"
2. Включите опцию "Always On"

### 6. Устранение неполадок

При возникновении проблем:

1. Проверьте логи бота:
   ```bash
   tail -n 100 pokemon_bot_workflow.log
   ```

2. Проверьте статус heartbeat-файла:
   ```bash
   cat bot_running.txt
   ```

3. Перезапустите воркфлоу вручную:
   ```bash
   ./stop_workflow_bot.sh
   sleep 5
   ./start_workflow_bot.sh
   ```

## Дополнительные рекомендации

1. **Регулярное резервное копирование**: Создавайте резервные копии данных бота (файлы JSON в папке `data/`).

2. **Мониторинг использования ресурсов**: Следите за использованием памяти и CPU в панели Replit.

3. **Настройка логирования**: Оптимизируйте уровни логирования для экономии дискового пространства.

4. **Обработка ошибок**: Улучшайте обработку исключений для предотвращения падений бота.

5. **Регулярные проверки**: Даже при настроенной системе 24/7, регулярно проверяйте работу бота вручную.

## Заключение

При правильной настройке по данному руководству, ваш бот должен работать круглосуточно 24/7 на платформе Replit. В случае любых сбоев система автоматически попытается восстановить работу бота.

Помните, что для действительно стабильной работы 24/7 рекомендуется использовать подписку Replit Hacker/Pro, так как бесплатный тариф имеет ограничения на ресурсы и время работы.