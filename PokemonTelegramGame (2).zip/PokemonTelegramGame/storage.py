import json
import os
import logging
import random
from typing import Dict, List, Optional, Any, Tuple
import time
import uuid
from models.pokemon import Pokemon
from models.user import User
from models.shop import Item, Promocode
from models.trainer import Trainer
import config

logger = logging.getLogger(__name__)

# In-memory data storage
users = {}
pokemons = {}
active_battles = {}
active_trades = {}
active_wild_pokemon = {}
promocodes = {}
custom_pokemons = {}

# Data file paths
DATA_DIR = "data"
USERS_FILE = os.path.join(DATA_DIR, "users.json")
POKEMONS_FILE = os.path.join(DATA_DIR, "pokemons.json")
PROMOCODES_FILE = os.path.join(DATA_DIR, "promocodes.json")
CUSTOM_POKEMONS_FILE = os.path.join(DATA_DIR, "custom_pokemons.json")

def initialize_data():
    """Initialize data by loading from JSON files if they exist."""
    # Create data directory if it doesn't exist
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR)
    
    # Load users
    if os.path.exists(USERS_FILE):
        try:
            with open(USERS_FILE, 'r') as f:
                user_dict = json.load(f)
                for user_id, user_data in user_dict.items():
                    users[int(user_id)] = User.from_dict(user_data)
            logger.info(f"Loaded {len(users)} users from {USERS_FILE}")
        except Exception as e:
            logger.error(f"Error loading users: {e}")
    
    # Load custom Pokemon
    if os.path.exists(CUSTOM_POKEMONS_FILE):
        try:
            with open(CUSTOM_POKEMONS_FILE, 'r') as f:
                custom_pokemons.update(json.load(f))
            logger.info(f"Loaded {len(custom_pokemons)} custom pokemons from {CUSTOM_POKEMONS_FILE}")
        except Exception as e:
            logger.error(f"Error loading custom pokemons: {e}")
    
    # Load promocodes
    if os.path.exists(PROMOCODES_FILE):
        try:
            with open(PROMOCODES_FILE, 'r') as f:
                promocode_dict = json.load(f)
                for code, promo_data in promocode_dict.items():
                    promocodes[code] = Promocode.from_dict(promo_data)
            logger.info(f"Loaded {len(promocodes)} promocodes from {PROMOCODES_FILE}")
        except Exception as e:
            logger.error(f"Error loading promocodes: {e}")
    
    logger.info("Data initialization complete")

def save_data():
    """Save all data to JSON files."""
    try:
        # Save users
        user_dict = {user_id: user.to_dict() for user_id, user in users.items()}
        with open(USERS_FILE, 'w') as f:
            json.dump(user_dict, f, indent=2)
        
        # Save custom pokemons
        with open(CUSTOM_POKEMONS_FILE, 'w') as f:
            json.dump(custom_pokemons, f, indent=2)
        
        # Save promocodes
        promocode_dict = {code: promo.to_dict() for code, promo in promocodes.items()}
        with open(PROMOCODES_FILE, 'w') as f:
            json.dump(promocode_dict, f, indent=2)
        
        logger.info("All data saved successfully")
    except Exception as e:
        logger.error(f"Error saving data: {e}")

def get_all_users() -> Dict[int, User]:
    """Get all users in the system."""
    return users

def get_user(user_id: int) -> Optional[User]:
    """Get a user by ID or create a new one if it doesn't exist."""
    if user_id not in users:
        users[user_id] = User(user_id=user_id, balance=config.STARTING_BALANCE)
    return users[user_id]

def save_user(user: User):
    """Save a user to the storage."""
    users[user.user_id] = user
    save_data()

def delete_user(user_id: int) -> bool:
    """Delete a user account from the storage.
    
    Returns:
        bool: True if user was deleted, False if user wasn't found
    """
    if user_id in users:
        del users[user_id]
        save_data()
        logger.info(f"Удален пользователь с ID {user_id}")
        return True
    return False

def get_custom_pokemon(pokemon_id: str) -> Optional[Dict]:
    """Get a custom Pokemon by ID."""
    return custom_pokemons.get(pokemon_id)

def add_custom_pokemon(pokemon_data: Dict) -> str:
    """Add a custom Pokemon and return its ID."""
    pokemon_id = str(uuid.uuid4())
    custom_pokemons[pokemon_id] = pokemon_data
    save_data()
    return pokemon_id

def get_user_pokemon(user_id: int, pokemon_name: str) -> List[Pokemon]:
    """Get all Pokemon with a specific name owned by the user."""
    user = get_user(user_id)
    return [pokemon for pokemon in user.pokemons if pokemon.name.lower() == pokemon_name.lower()]

def add_pokemon_to_user(user_id: int, pokemon: Pokemon) -> bool:
    """Add a Pokemon to a user's collection."""
    user = get_user(user_id)
    
    # Check if user already has 3 of this Pokemon
    same_pokemon_count = len([p for p in user.pokemons if p.name.lower() == pokemon.name.lower()])
    if same_pokemon_count >= config.MAX_SAME_POKEMON:
        return False
    
    user.pokemons.append(pokemon)
    user.caught_pokemon_count += 1
    
    # Update user's league based on caught Pokemon count
    update_user_league(user)
    
    save_user(user)
    return True

def update_user_league(user: User):
    """Update a user's league based on their caught Pokemon count."""
    current_league = user.league
    
    # Check if user qualifies for a higher league
    for league_num in sorted(config.LEAGUES.keys(), reverse=True):
        league_data = config.LEAGUES[league_num]
        if user.caught_pokemon_count >= league_data["pokemon_required"] and league_num > current_league:
            user.league = league_num
            return

def get_wild_pokemon(chat_id: int) -> Optional[Dict]:
    """Get the active wild Pokemon for a chat."""
    return active_wild_pokemon.get(chat_id)

def set_wild_pokemon(chat_id: int, pokemon_data: Dict):
    """Set the active wild Pokemon for a chat."""
    active_wild_pokemon[chat_id] = {
        "data": pokemon_data,
        "timestamp": time.time(),
        "caught": False
    }

def clear_wild_pokemon(chat_id: int):
    """Clear the active wild Pokemon for a chat."""
    if chat_id in active_wild_pokemon:
        del active_wild_pokemon[chat_id]

def is_wild_pokemon_available(chat_id: int) -> bool:
    """Check if a wild Pokemon is available in the chat."""
    if chat_id not in active_wild_pokemon:
        return False
    
    # Проверяем только что покемон не пойман
    pokemon_data = active_wild_pokemon[chat_id]
    return not pokemon_data["caught"]

def mark_wild_pokemon_caught(chat_id: int):
    """Mark the wild Pokemon as caught."""
    if chat_id in active_wild_pokemon:
        active_wild_pokemon[chat_id]["caught"] = True

def start_battle(user1_id: int, user2_id: int) -> str:
    """Start a battle between two users."""
    battle_id = str(uuid.uuid4())
    active_battles[battle_id] = {
        "user1_id": user1_id,
        "user2_id": user2_id,
        "status": "pending",
        "user1_ready": False,
        "user2_ready": False,
        "result": None,
        "timestamp": time.time()
    }
    return battle_id

def get_battle(battle_id: str) -> Optional[Dict]:
    """Get a battle by ID."""
    return active_battles.get(battle_id)

def set_user_ready_for_battle(battle_id: str, user_id: int) -> bool:
    """Set a user as ready for battle."""
    battle = get_battle(battle_id)
    if not battle:
        return False
    
    if user_id == battle["user1_id"]:
        battle["user1_ready"] = True
    elif user_id == battle["user2_id"]:
        battle["user2_ready"] = True
    else:
        return False
    
    # If both users are ready, start the battle
    if battle["user1_ready"] and battle["user2_ready"]:
        battle["status"] = "in_progress"
    
    return True

def finish_battle(battle_id: str, winner_id: int, loser_id: int, reward: int):
    """Finish a battle with a winner and reward."""
    battle = get_battle(battle_id)
    if not battle:
        return False
    
    battle["status"] = "completed"
    battle["result"] = {
        "winner_id": winner_id,
        "loser_id": loser_id,
        "reward": reward
    }
    
    # Give rewards to the winner
    winner = get_user(winner_id)
    winner.balance += reward
    save_user(winner)
    
    # Clean up old battles
    cleanup_old_battles()
    
    return True

def cleanup_old_battles():
    """Remove battles that are older than 1 hour."""
    current_time = time.time()
    to_remove = []
    
    for battle_id, battle in active_battles.items():
        if current_time - battle["timestamp"] > 3600:  # 1 hour in seconds
            to_remove.append(battle_id)
    
    for battle_id in to_remove:
        del active_battles[battle_id]

def start_trade(user1_id: int, user2_id: int) -> str:
    """Start a trade between two users."""
    trade_id = str(uuid.uuid4())
    active_trades[trade_id] = {
        "user1_id": user1_id,
        "user2_id": user2_id,
        "user1_offer": [],
        "user2_offer": [],
        "user1_confirmed": False,
        "user2_confirmed": False,
        "status": "negotiating",
        "timestamp": time.time()
    }
    return trade_id

def get_trade(trade_id: str) -> Optional[Dict]:
    """Get a trade by ID."""
    return active_trades.get(trade_id)

def add_pokemon_to_trade(trade_id: str, user_id: int, pokemon_id: str) -> bool:
    """Add a Pokemon to a trade offer."""
    trade = get_trade(trade_id)
    if not trade:
        return False
    
    user = get_user(user_id)
    
    # Find the Pokemon in the user's collection
    pokemon = None
    for p in user.pokemons:
        if p.pokemon_id == pokemon_id:
            pokemon = p
            break
    
    if not pokemon:
        return False
    
    # Add the Pokemon to the offer
    if user_id == trade["user1_id"]:
        trade["user1_offer"].append(pokemon_id)
        trade["user1_confirmed"] = False
        trade["user2_confirmed"] = False
    elif user_id == trade["user2_id"]:
        trade["user2_offer"].append(pokemon_id)
        trade["user1_confirmed"] = False
        trade["user2_confirmed"] = False
    else:
        return False
    
    return True

def remove_pokemon_from_trade(trade_id: str, user_id: int, pokemon_id: str) -> bool:
    """Remove a Pokemon from a trade offer."""
    trade = get_trade(trade_id)
    if not trade:
        return False
    
    if user_id == trade["user1_id"] and pokemon_id in trade["user1_offer"]:
        trade["user1_offer"].remove(pokemon_id)
        trade["user1_confirmed"] = False
        trade["user2_confirmed"] = False
    elif user_id == trade["user2_id"] and pokemon_id in trade["user2_offer"]:
        trade["user2_offer"].remove(pokemon_id)
        trade["user1_confirmed"] = False
        trade["user2_confirmed"] = False
    else:
        return False
    
    return True

def confirm_trade(trade_id: str, user_id: int) -> bool:
    """Confirm a trade offer."""
    trade = get_trade(trade_id)
    if not trade:
        return False
    
    if user_id == trade["user1_id"]:
        trade["user1_confirmed"] = True
    elif user_id == trade["user2_id"]:
        trade["user2_confirmed"] = True
    else:
        return False
    
    # If both users confirmed, execute the trade
    if trade["user1_confirmed"] and trade["user2_confirmed"]:
        return execute_trade(trade_id)
    
    return True

def execute_trade(trade_id: str) -> bool:
    """Execute a confirmed trade."""
    trade = get_trade(trade_id)
    if not trade:
        return False
    
    user1 = get_user(trade["user1_id"])
    user2 = get_user(trade["user2_id"])
    
    # Get the Pokemon objects from their IDs
    user1_pokemons = []
    for pokemon_id in trade["user1_offer"]:
        for pokemon in user1.pokemons:
            if pokemon.pokemon_id == pokemon_id:
                user1_pokemons.append(pokemon)
                break
    
    user2_pokemons = []
    for pokemon_id in trade["user2_offer"]:
        for pokemon in user2.pokemons:
            if pokemon.pokemon_id == pokemon_id:
                user2_pokemons.append(pokemon)
                break
    
    # Remove the Pokemon from their original owners
    for pokemon in user1_pokemons:
        user1.pokemons.remove(pokemon)
    
    for pokemon in user2_pokemons:
        user2.pokemons.remove(pokemon)
    
    # Add the Pokemon to their new owners
    for pokemon in user1_pokemons:
        user2.pokemons.append(pokemon)
    
    for pokemon in user2_pokemons:
        user1.pokemons.append(pokemon)
    
    # Save the changes
    save_user(user1)
    save_user(user2)
    
    # Mark the trade as completed
    trade["status"] = "completed"
    
    # Clean up old trades
    cleanup_old_trades()
    
    return True

def cleanup_old_trades():
    """Remove trades that are older than 1 hour."""
    current_time = time.time()
    to_remove = []
    
    for trade_id, trade in active_trades.items():
        if current_time - trade["timestamp"] > 3600:  # 1 hour in seconds
            to_remove.append(trade_id)
    
    for trade_id in to_remove:
        del active_trades[trade_id]

def create_promocode(
    code: str, 
    reward_type: str = "coins", 
    reward_value: Any = 0, 
    reward_amount: int = 1,
    created_by: int = 0,
    description: str = "",
    expires_at: Optional[float] = None,
    max_uses: Optional[int] = None
) -> Promocode:
    """Create a new promocode with extended functionality.
    
    Args:
        code: Код промокода
        reward_type: Тип награды ("coins", "pokemon", "trainer", "custom_pokemon")
        reward_value: Значение награды (количество монет, имя покемона/тренера, ID уникального покемона)
        reward_amount: Количество наград (только для покемонов)
        created_by: ID администратора, создавшего промокод
        description: Описание промокода
        expires_at: Время истечения промокода (Unix timestamp)
        max_uses: Максимальное количество использований
        
    Returns:
        Созданный промокод
    """
    promocode = Promocode(
        code=code, 
        reward_type=reward_type, 
        reward_value=reward_value,
        reward_amount=reward_amount, 
        created_by=created_by,
        description=description,
        expires_at=expires_at,
        max_uses=max_uses
    )
    promocodes[code] = promocode
    save_data()
    return promocode

def get_promocode(code: str) -> Optional[Promocode]:
    """Get a promocode by its code."""
    return promocodes.get(code)

def use_promocode(user_id: int, code: str) -> Tuple[bool, str, Any]:
    """Use a promocode and return whether it was successful, the reward type and value.
    
    Returns:
        Tuple[bool, str, Any]: (успех, тип награды, значение награды)
    """
    promocode = get_promocode(code)
    if not promocode:
        return False, "", None
    
    # Проверка валидности промокода
    if not promocode.is_valid():
        return False, "", None
    
    user = get_user(user_id)
    
    # Check if the user has already used this promocode
    if promocode.code in user.used_promocodes:
        return False, "", None
    
    # Mark the promocode as used by this user
    user.used_promocodes.append(promocode.code)
    
    # Применяем награду в зависимости от типа
    reward_description = promocode.get_reward_description()
    
    # Обрабатываем разные типы наград
    if promocode.reward_type == "coins":
        # Монеты - просто добавляем к балансу
        user.balance += int(promocode.reward_value)
    
    elif promocode.reward_type == "pokemon":
        # Обычный покемон - создаем и добавляем пользователю
        pokemon_name = promocode.reward_value
        for _ in range(promocode.reward_amount):
            pokemon_data = get_pokemon_data_sync(pokemon_name.lower())
            if pokemon_data:
                pokemon = Pokemon.from_pokeapi(pokemon_data)
                user.pokemons.append(pokemon)
                user.caught_pokemon_count += 1
    
    elif promocode.reward_type == "trainer":
        # Тренер - устанавливаем пользователю
        trainer_id = promocode.reward_value
        if trainer_id in config.TRAINERS:
            user.trainer = trainer_id
            user.trainer_level = 1
    
    elif promocode.reward_type == "custom_pokemon":
        # Уникальный покемон - добавляем пользователю
        custom_pokemon_id = promocode.reward_value
        pokemon_data = get_custom_pokemon(custom_pokemon_id)
        if pokemon_data:
            custom_pokemon = Pokemon.create_custom_pokemon(
                name=pokemon_data["name"],
                types=pokemon_data["types"],
                attack=pokemon_data["stats"]["attack"],
                defense=pokemon_data["stats"]["defense"],
                hp=pokemon_data["stats"]["hp"],
                image_url=pokemon_data.get("image_url", "")
            )
            user.pokemons.append(custom_pokemon)
            user.caught_pokemon_count += 1
    
    # Увеличиваем счетчик использований промокода
    promocode.use()
    
    # Сохраняем изменения
    save_user(user)
    save_data()  # Сохраняем обновленный счетчик использований промокода
    
    return True, promocode.reward_type, reward_description
