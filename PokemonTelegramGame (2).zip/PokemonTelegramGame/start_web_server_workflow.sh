#!/bin/bash
# Скрипт для запуска веб-сервера через Replit Workflow

echo "Запуск веб-сервера через Replit Workflow..."

# Обновляем конфигурацию воркфлоу
echo "Обновление конфигурации воркфлоу..."
cat > .replit.d/persistent_workflows/web_server.yml << EOF
name: web_server
description: Веб-сервер для мониторинга бота покемонов
run: python3 ping_endpoint.py
persistent: true
onBoot: true
language: python3
EOF

echo "Запуск воркфлоу web_server..."
curl -X POST "https://replit.com/api/v1/replworkflows/run" \
  -H "X-Requested-With: replit" \
  -H "Origin: https://replit.com" \
  -H "Accept: application/json" \
  -H "Content-Type: application/json" \
  -H "Accept-Language: ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7" \
  -H "User-Agent: Mozilla/5.0" \
  -d "{\"name\":\"web_server\",\"repl\":\"$REPL_SLUG\",\"resources\":{}}"

echo "Веб-сервер запущен в режиме воркфлоу!"
echo "Логи доступны в Replit Workflow: web_server"
echo "Мониторинг доступен по адресу: https://$REPL_SLUG.$REPL_OWNER.repl.co/health"
echo "Для мониторинга с UptimeRobot используйте: https://$REPL_SLUG.$REPL_OWNER.repl.co/ping"