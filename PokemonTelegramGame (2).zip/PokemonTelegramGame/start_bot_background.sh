#!/bin/bash

# Создание директории данных
mkdir -p data

# Проверка состояния бота
echo "Проверка конфигурации Telegram бота..."
python telegram_bot_status.py

# Запуск бота в фоновом режиме
echo "Запуск Telegram бота в фоновом режиме..."
nohup python run_polling_bot.py > bot_logs.log 2>&1 &

# Вывод ID процесса
BOT_PID=$!
echo "Бот запущен с PID: $BOT_PID"
echo "Логи сохраняются в файл bot_logs.log"
